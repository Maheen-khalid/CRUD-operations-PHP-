<?php
include 'config.php';
?>
<style type="text/css">
	table{
		width: 80%;
		border:solid;
	}
	table thead{
		background-color: black;
		color: white;
		justify-content: center;
	}
	table thead th{
		font-size: 15px;
		padding: 5px;
	}
	table tbody td{
		padding: 10px;
	}
    table td a{
        text-decoration:none;
        color:white;
        padding:25px;
        padding-left: 40px;
    }

</style>
<center>
<table>
	<thead>
		<th>S. No</th>
		<th>Product Name</th>
		<th>Product Price</th>
		<th>Product Description</th>
        <th>Update Product</th>
        <th>Delete Product </th>
	
		
	</thead>
	<tbody>
		<?php  
				
			$fetch_products = "select * from `products`";
			$execute_fp = mysqli_query($conn, $fetch_products);

			$count = 1;
			while ($row = mysqli_fetch_assoc($execute_fp)) {
				# code...
				$id = $row['id'];
				$Name = $row['name'];
				$Price = $row['price'];
				$Description = $row['description'];


			
		?>
		<tr>
		<td><?php echo $count; ?></td>
		<td><?php echo $Name; ?></td>
		<td><?php echo $Price; ?></td>
		<td><?php echo $Description; ?></td>
        <td style="background-color:green">
        <a href='update.php?id=<?php echo $row['id'] ?>' >Update</a></td>
        <td style="background-color:red"><a href="delete.php?id=<?php echo $row['id'] ?>">Delete</a></td>
		
		</tr>
		<?php
			$count++;
	}
	?>
	</tbody>
</table>
</center>