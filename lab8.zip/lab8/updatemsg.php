<?php 
include 'config.php';
$productid=$_GET['id'];
  if (isset($_POST['submit'])) {

    $first_name = $_POST['name'];

    $price = $_POST['price'];

    $description = $_POST['description'];

    $sql="UPDATE `products` SET `name`='$first_name',`price`='$price',`description`='$description' WHERE id={$productid};";

    if ($conn->query($sql) == TRUE) {
        header('location:products.php');
        exit();

    }
    else{

      echo "Error:". $sql . "<br>". $conn->error;

    }

    $conn->close();

  } 

?>