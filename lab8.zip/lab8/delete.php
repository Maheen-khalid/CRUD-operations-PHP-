<?php 
include 'config.php';
$productid=$_GET['id'];
$del_product = "DELETE FROM `products` WHERE id={$productid}";
$execute_fp = mysqli_query($conn, $del_product);
if ($conn->query($del_product) == TRUE) {
    header('location:products.php');
    exit();

}
else{

  echo "Error:". $sql . "<br>". $conn->error;

}

$conn->close();


?>