<?php 

include "config.php";

  if (isset($_POST['submit'])) {

    $first_name = $_POST['name'];

    $price = $_POST['price'];

    $description = $_POST['description'];

    $sql = "INSERT INTO products (id ,name, price, description) 
    VALUES ('','$first_name','$price','$description')";

    // $sql ="INSERT INTO `products`( `name`, `price`, `description`)
    //  VALUES ('$first_name','$price','$description')";

    $result = $conn->query($sql);

    if ($result == TRUE) {
        header('location:products.php');
        exit();

    }
    else{

      echo "Error:". $sql . "<br>". $conn->error;

    }

    $conn->close();

  } 

?>